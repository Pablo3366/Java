package unidad3;

public class SimpleCalculator {
    
    
    public static void main(String[] args) {
        
        Operaciones calc = new Operaciones();
        calc.capturar();
        calc.mostrar();
    }
    

    
}
