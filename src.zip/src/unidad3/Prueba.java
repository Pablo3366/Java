package unidad3;

public class Prueba {

    public static void main(String[] args){
        //Fibonacci.imprimirrec(50);
        //Fibonacci.imprimir();
        
        //Factorial.imprimir("La factorial es: ",
        //        Factorial.calcular(Factorial.capturar("Ingrese numero: ")));
        
        Range prueba = new Range();
        prueba.calcular(40, 0);
        prueba.imprimir("\nLos resultados son:");

//        PagoDelAgua prueba = new PagoDelAgua();
//        prueba.run();
    }
    
}
