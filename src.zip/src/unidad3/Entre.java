package unidad3;

public class Entre {

    public static void main(String[] args) {
        int min = 1, max = 10;
        
        Between.verificar(min, max);
    }
    
}
