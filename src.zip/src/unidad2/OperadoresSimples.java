package operadoressimples;

public class OperadoresSimples {

    public static void main(String[] args) {
        int a = 6;
        int b = 2;
        int resultado;
        
        resultado = a + b;
        System.out.println(a + " + " + b +  " es " + resultado);
        
        resultado = a - b;
        System.out.println(a + " - " + b +  " es " + resultado);
        
        resultado = a * b;
        System.out.println(a + " x " + b +  " es " + resultado);
    }
    
}