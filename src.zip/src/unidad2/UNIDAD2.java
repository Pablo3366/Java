package unidad2;

public class UNIDAD2 {

    public static void main(String[] args) {
        Desviacion prueba = new Desviacion();
        //prueba.run();
        
        Gravedad prueba2 = new Gravedad();
        prueba2.run();
        
    }
}























/*Scanner teclado = new Scanner(System.in);
        System.out.println("Programa para convertir " +
                "de Celsius a Fehrenheit");
        System.out.print("Ingrese el valor en Celsius >>>");
        
        //Captura y calculo
        int celsius = teclado.nextInt();
        float fahrenheit = 9/5.0f * celsius + 32;
        
        //Salida
        System.out.println(celsius + "grados ceslius son " + 
               fahrenheit + "grados fahrenheit");*/