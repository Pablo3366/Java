package divisionporcero;

public class DivisionPorCero {

    public static void main(String[] args) {
        double resultado1 = 5.7 / 0.0;
        double resultado2 = 0.0 / 0.0;
        
        System.out.println("El resultado 1 es " + resultado1);
        System.out.println("El resultado 2 es " + resultado2);
        
        int resultado3 = 4/0;
        
        System.out.println("El resultado 3 es " + +resultado3);
    }
    
}
