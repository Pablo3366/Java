/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tipos.de.datos;

/**
 *
 * @author lap
 */
public class TiposDeDatos {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println("\tMin\t\tMax");
        System.out.println("byte \t" + Byte.MIN_VALUE + "\t\t" + Byte.MAX_VALUE);
        System.out.println("short\t" + Short.MIN_VALUE + "\t\t" + Short.MAX_VALUE);
        System.out.println("int\t" + Integer.MIN_VALUE + "\t" +
                Integer.MAX_VALUE);
    }
    
}
